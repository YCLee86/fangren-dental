# 診所排班工具：公開同步包

此資料夾供 `YCLee86/fangren-dental` 跨電腦接續使用。

## 去識別原則

- 員工編號保留，員工姓名已移除。
- 原始 Excel 不在此包內，也未被覆寫。
- 含姓名的預覽圖、檢查紀錄與本機路徑未納入。
- `work/` 腳本中的姓名範例已以員編代稱，路徑已改為相對路徑。

## 內容

- `outputs/clinic-assistant-model/assistant_skill_matrix_v1_pilot.xlsx`：去識別 Excel。
- `outputs/*.md`：續作交接與跨電腦進度比對紀錄。
- `work/*.mjs`：建置、檢查及維護腳本的去識別副本。
- `manifest.json`：同步範圍與去識別統計。

注意：部分早期建置腳本需要未納入公開包的 `inputs/assistant_skill_matrix.xlsx`。目前成果可直接從已同步的去識別 Excel 接續。
